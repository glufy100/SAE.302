"""Serveur du carrefour intelligent."""
